"""

This example demonstrates how to write a custom highlighter.

"""

from random import randint

from rich import print
from rich.highlighter import Highlighter


#class RainbowHighlighter(Highlighter):
#    def highlight(self, text):
#        c = "#73fe2d"
#        for j in COLOR_MAP.keys():
#            if int(i) <= j:
#                c = COLOR_MAP[j]
#
#        text.stylize(f"color({c})", 0, -1)

class RainbowHighlighter(Highlighter):
    def highlight(self, text):
#        for index in range(len(text)):
        text.stylize(f"color('#e7fe2d')", 0, None)


rainbow = RainbowHighlighter()
print(rainbow("I must not fear. Fear is the mind-killer."))
